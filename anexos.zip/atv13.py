import tkinter as tk
from tkinter import messagebox

def salvar_compromisso():
    compromisso = entrada_compromisso.get()
    if compromisso.strip() == "":
        messagebox.showwarning("Aviso", "Digite um compromisso antes de salvar.")
        return
    lista_compromissos.insert(tk.END, compromisso)
    entrada_compromisso.delete(0, tk.END)

def sair_aplicacao():
    janela.destroy()

janela = tk.Tk()
janela.title("Compromissos")
janela.geometry("400x300")

tk.Label(janela, text="Digite o compromisso:").pack(pady=5)
entrada_compromisso = tk.Entry(janela, width=50)
entrada_compromisso.pack(pady=5)

btn_salvar = tk.Button(janela, text="Salvar", command=salvar_compromisso)
btn_salvar.pack(pady=5)

lista_compromissos = tk.Listbox(janela, width=50, height=10)
lista_compromissos.pack(pady=10)

btn_sair = tk.Button(janela, text="Sair", command=sair_aplicacao)
btn_sair.pack(pady=5)

janela.mainloop()
