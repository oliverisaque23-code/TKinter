import tkinter as tk

def muda_cor_vermelha():
    janela.configure(bg="red")

def muda_cor_verde():
    janela.configure(bg="green")

def muda_cor_azul():
    janela.configure(bg="blue")

janela = tk.Tk()
janela.title("Janela Colorida")
janela.geometry("400x300")

btn_vermelho = tk.Button(janela, text="Vermelho", command=muda_cor_vermelha, width=10)
btn_vermelho.pack(pady=10)

btn_verde = tk.Button(janela, text="Verde", command=muda_cor_verde, width=10)
btn_verde.pack(pady=10)

btn_azul = tk.Button(janela, text="Azul", command=muda_cor_azul, width=10)
btn_azul.pack(pady=10)

janela.mainloop()