import tkinter as tk

# Criar a janela principal
janela = tk.Tk()

# Definir o título da janela
janela.title("Minha Primeira Janela")

# Definir o tamanho da janela (largura x altura)
janela.geometry("400x300")

# Iniciar o loop da aplicação (exibe a janela)
janela.mainloop()
