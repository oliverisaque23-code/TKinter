import tkinter as tk

def dizer_ola():
    nome = entrada_nome.get()
    rotulo_resultado.config(text=f"Olá, {nome}.")

janela = tk.Tk()
janela.title("Cumprimento com Nome")
janela.geometry("300x150")

entrada_nome = tk.Entry(janela, width=30)
entrada_nome.pack(pady=10)

botao_enviar = tk.Button(janela, text="Enviar", command=dizer_ola)
botao_enviar.pack()

rotulo_resultado = tk.Label(janela, text="")
rotulo_resultado.pack(pady=10)

janela.mainloop()