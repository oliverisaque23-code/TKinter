import tkinter as tk

def atualizar_mensagem(mensagem):
    rotulo.config(text=mensagem)
    
janela = tk.Tk()
janela.title("Saudações")
janela.geometry("300x150")

rotulo = tk.Label(janela, text="", font=("Arial", 14))
rotulo.pack(pady=10)

btn_bom_dia = tk.Button(janela, text="Bom dia", command=lambda: atualizar_mensagem("Bom dia!"))
btn_bom_dia.pack(side="left", expand=True, padx=10)

btn_boa_tarde = tk.Button(janela, text="Boa tarde", command=lambda: atualizar_mensagem("Boa tarde!"))
btn_boa_tarde.pack(side="left", expand=True, padx=10)

btn_boa_noite = tk.Button(janela, text="Boa noite", command=lambda: atualizar_mensagem("Boa noite!"))
btn_boa_noite.pack(side="left", expand=True, padx=10)


janela.mainloop()
