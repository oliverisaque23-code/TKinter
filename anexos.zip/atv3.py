import tkinter as tk

def clicar_botao():
    rotulo.config(text="Botão clicado!")

janela = tk.Tk()
janela.title("Exemplo de Botão e Rótulo")
janela.geometry("300x150")

rotulo = tk.Label(janela, text="Clique no botão.")
rotulo.pack(pady=10) 

botao = tk.Button(janela, text="Clique aqui", command=clicar_botao)
botao.pack()

janela.mainloop()
