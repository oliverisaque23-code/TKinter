import tkinter as tk

def contador_regressivo(contador):
    if contador >= 0:
        rotulo.config(text=str(contador))
      
        janela.after(1000, contador_regressivo, contador - 1)
    else:
        rotulo.config(text="Fim!")

# Criar janela principal
janela = tk.Tk()
janela.title("Contador Regressivo")
janela.geometry("200x100")


rotulo = tk.Label(janela, text="", font=("Arial", 40))
rotulo.pack(expand=True)


contador_regressivo(10)


janela.mainloop()
