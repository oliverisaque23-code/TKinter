import tkinter as tk

contador = 0

def contar_clique():
    global contador
    contador += 1
    rotulo.config(text=f"Botão clicado {contador} vezes")

janela = tk.Tk()
janela.title("Contador de Cliques")
janela.geometry("300x150")

rotulo = tk.Label(janela, text="Botão clicado 0 vezes")
rotulo.pack(pady=10)

botao = tk.Button(janela, text="Clique aqui", command=contar_clique)
botao.pack()

janela.mainloop()
