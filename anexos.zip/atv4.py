import tkinter as tk

janela = tk.Tk()
janela.title("Meu App Colorido")
janela.geometry("500x300")
janela.configure(bg="yellow")  

janela.mainloop()
