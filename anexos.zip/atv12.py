import tkinter as tk

janela = tk.Tk()
janela.title("Rótulo Personalizado")
janela.geometry("300x100")


rotulo = tk.Label(janela, text="Texto Personalizado", font=("Arial", 20), fg="blue")
rotulo.pack(pady=20)

janela.mainloop()
