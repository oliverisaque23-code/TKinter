import tkinter as tk

def sair():
    janela.destroy()

janela = tk.Tk()
janela.title("Janela com Botão Sair")
janela.geometry("200x100")

btn_sair = tk.Button(janela, text="Sair", command=sair)
btn_sair.pack(expand=True)

janela.mainloop()
