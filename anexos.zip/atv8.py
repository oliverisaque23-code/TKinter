import tkinter as tk
from tkinter import messagebox

def verificar_login():
    usuario = entrada_usuario.get()
    senha = entrada_senha.get()
    
    if usuario == "admin" and senha == "123":
        messagebox.showinfo("Login", "Acesso permitido")
    else:
        messagebox.showerror("Login", "Acesso negado")

janela = tk.Tk()
janela.title("Tela de Login")
janela.geometry("300x180")

tk.Label(janela, text="Usuário:").pack(pady=5)
entrada_usuario = tk.Entry(janela)
entrada_usuario.pack()

tk.Label(janela, text="Senha:").pack(pady=5)
entrada_senha = tk.Entry(janela, show="*") 
entrada_senha.pack()

btn_login = tk.Button(janela, text="Entrar", command=verificar_login)
btn_login.pack(pady=15)

janela.mainloop()
